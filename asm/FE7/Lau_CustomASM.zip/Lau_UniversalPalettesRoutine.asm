
UniversalCustomPaletteCheck:
push {r3,r4}
ldr r2,=CustomPalettesTable
ldr r3,[r0]
ldrb r3,[r3,0x4]

PaletteCheckLoop:
ldrb r4,[r2]
cmp r4,0x0
beq UseDefaultMapSpritePalette
cmp r3,r4
beq UnitHasCustomSpriteEntry
add r2,0x10
b PaletteCheckLoop
UseDefaultMapSpritePalette:
pop {r3,r4}
mov r0,0x0
bx r14
UnitHasCustomSpriteEntry:
ldr r3,[r2,0xC]
lsl r4,r1,0x2
ldr r3,[r3,r4]
cmp r3,0x0
bne UnitHasCustomSpriteEntryData
pop {r3,r4}
mov r0,0x0
bx r14

UnitHasCustomSpriteEntryData:
ldrb r3,[r2,0x2]
cmp r3,0x10
bge UnitFactionFail
ldr r4,=ucpc_paletteCheckTable
lsl r3,r3,0x2
ldr r4,[r4,r3]
add r4,0x1
mov r15,r4

UnitFactionAligns:
ldr r4,[r2,0x8]
cmp r4,0x0
beq NoCustomASMCheck_UCP
push {r14}
ldr r3,=ucpc_asm_return+1
mov r14,r3
mov r15,r4
ucpc_asm_return:
pop {r1}
cmp r2,0x0
bne NoCustomASMCheck_UCP
UnitFactionFail:
pop {r3,r4}
mov r0,0x0
bx r1

NoCustomASMCheck_UCP:
add r2,0x4
ldrb r3,[r2,r1]
cmp r3,0x0
beq ucpc_NoFlag
push {r4}
push {r0,r1,r2}
mov r0,r3
ldr r1,=ucpc_flag_return+1
mov r14,r1
ldr r1,=0x80798F8+1
mov r15,r1
ucpc_flag_return:
cmp r0,0x0
bne ucpc_NoFlag_2
pop {r0,r1,r2}
pop {r1}
pop {r3,r4}
mov r0,0x0
bx r1

ucpc_NoFlag_2:
pop {r0,r1,r2}
ucpc_NoFlag:
lsl r3,r1,0x2
ldr r0,[r2,0x8]
ldr r0,[r0,r3]
pop {r3,r4}
bx r14
.pool


.align 4
ucpc_paletteCheckTable:
.dw UnitFactionAligns
.dw CUPCheck_Player
.dw CUPCheck_Enemy
.dw CUPCheck_PlayerEnemy
.dw CUPCheck_NPC
.dw CUPCheck_PlayerNPC
.dw CUPCheck_EnemyNPC
.dw CUPCheck_PlayerEnemyNPC
.dw CUPCheck_Other
.dw CUPCheck_OtherPlayer
.dw CUPCheck_OtherEnemy
.dw CUPCheck_OtherPlayerEnemy
.dw CUPCheck_OtherNPC
.dw CUPCheck_OtherPlayerNPC
.dw CUPCheck_OtherEnemyNPC
.dw UnitFactionAligns

CUPCheck_Player:
cmp r3,0x40
blt ucpf_true
b ucpf_false

CUPCheck_Enemy:
cmp r3,0x80
blt ucpf_false
cmp r3,0xC0
blt ucpf_true
b ucpf_false

CUPCheck_PlayerEnemy:
cmp r3,0x40
blt ucpf_true
cmp r3,0xC0
blt ucpf_true
b ucpf_false

CUPCheck_NPC:
cmp r3,0x40
blt ucpf_false
cmp r3,0x80
bge ucpf_false
b ucpf_false

CUPCheck_PlayerNPC:
cmp r3,0x80
blt ucpf_true
b ucpf_false

CUPCheck_EnemyNPC:
cmp r3,0x40
blt ucpf_false
cmp r3,0xC0
bge ucpf_false
b ucpf_true

CUPCheck_PlayerEnemyNPC:
cmp r3,0xC0
blt ucpf_true
b ucpf_false

CUPCheck_Other:
cmp r3,0xC0
bge ucpf_true
b ucpf_false

CUPCheck_OtherPlayer:
cmp r3,0x40
blt ucpf_true
cmp r3,0xC0
bge ucpf_true
b ucpf_false

CUPCheck_OtherEnemy:
cmp r3,0x80
bge ucpf_true
b ucpf_false

CUPCheck_OtherPlayerEnemy:
cmp r3,0x80
bge ucpf_true
cmp r3,0x40
blt ucpf_true
b ucpf_false

CUPCheck_OtherNPC:
cmp r3,0xC0
bge ucpf_true
cmp r3,0x40
blt ucpf_false
cmp r3,0x80
blt ucpf_true
b ucpf_false

CUPCheck_OtherPlayerNPC:
cmp r3,0xC0
bge ucpf_true
cmp r3,0x40
blt ucpf_false
b ucpf_false

CUPCheck_OtherEnemyNPC:
cmp r3,0x40
bge ucpf_true
b ucpf_false

ucpf_true:
ldr r4,=UnitFactionAligns+1
mov r15,r4
.pool
ucpf_false:
ldr r4,=UnitFactionFail+1
mov r15,r4
.pool

