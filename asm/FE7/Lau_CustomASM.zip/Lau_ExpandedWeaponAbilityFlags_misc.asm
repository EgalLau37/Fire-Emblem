
.org 0x802A1C8
ldr r0,=WeaponTriangleFlags_routine+1
mov r15,r0
.pool
mov r3,r3

.org 0x8028F38
ldr r1,=CheckEclipseApocalypse_damage+1
mov r15,r1
.pool

.org 0x80293C0	;also checks for status infliction
ldr r1,=CheckCannotDouble_eclipse+1
mov r15,r1
.pool

.org 0x80293F0
ldr r1,=CheckDevilReversal+1
mov r15,r1
.pool

.org 0x8029460
ldr r1,=CheckLifesteal+1
mov r15,r1
.pool

.org 0x80290A2
ldr r1,=CheckCanDouble+1
mov r15,r1
.align 4
.pool

.org 0x8016304	;useability check
.dw 0x12000

.org 0x8017ABC	;useability check, auto-level
.dw 0x12000

.org 0x80294A4
ldr r0,=CheckDecrementDurabilityMiss+1
mov r15,r0
.pool

.org 0x8051FB2
ldr r1,=CheckForceRangeDistance+1
mov r15,r1
.align 4
.pool

.org 0x8028520
ldr r1,=CheckCannotCritical
mov r15,r1
.pool

.org 0x802855C
ldr r1,=CheckApocEclipse_dashDamage
mov r15,r1
.pool

.org 0x8022606	;discard command
mov r1,0x8
lsl r1,r1,0x10
and r1,r0
cmp r1,0x0
bne 0x802261C
mov r0,0x1
b 0x802261E

.org 0x8017352	;drop, prep screen price value
mov r1,0x8
and r0,r1
cmp r0,0x0
beq 0x8017364
ldrh r0,[r2,0x1A]
b 0x801736A

.org 0x8098800	;drop, prep screen price display
mov r5,r0
cmp r5,0x0
beq 0x8098816
mov r0,r4
bl 0x801727C
mov r1,0x8
mov r3,r3
and r0,r1
cmp r0,0x0
beq 0x8098840

.org 0x8028EFA
mov r3,r3
.org 0x8028F06	;battle forecast, critical rate
mov r1,r4
ldr r1,[r1,0x4C]
mov r2,0x4
lsl r2,r2,0x18
and r1,r2
cmp r1,0x0
beq 0x8028F34
mov r0,r4
add r0,0x6A
mov r1,0x0
strh r1,[r0]
b 0x8028F34


.if UncounterableCheck == "vanilla"
ldr r0,[r4,0x4C]
ldr r1,[r3,0x4C]
orr r0,r1
.endif
.if UncounterableCheck == "attackerOnly"
.org 0x802A1FA	;change uncounter check to only check attacker
ldr r0,[r4,0x4C]
mov r3,r3
mov r3,r3
.endif
.if UncounterableCheck == "defenderOnly"
.org 0x802A1FA	;change uncounter check to only check defender
ldr r0,[r3,0x4C]
mov r3,r3
mov r3,r3
.endif

