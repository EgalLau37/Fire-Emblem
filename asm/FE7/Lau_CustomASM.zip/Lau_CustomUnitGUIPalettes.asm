
CustomMapSpritePalette_return:
cmp r0,0x0
beq StandardMapSpritePaletteCheck
cmp r0,0x10
bge UseCustomPaletteSlot
pop {r1,r2}
bx r2

StandardMapSpritePaletteCheck:
ldr r1,=StandardMapSpritePaletteCheck_routine+1
mov r15,r1

UseCustomPaletteSlot:
ldr r1,=UseCustomPaletteSlot_routine+1
mov r15,r1

StandardMapSpritePaletteCheck_routine:
pop {r0}
pop {r1}
mov r14,r1
ldrb r0,[r0,0xB]
lsr r0,r0,0x5
lsr r0,r0,0x1
cmp r0,0x3
ble ValidSpriteInput
mov r0,0x4
ValidSpriteInput:
ldr r1,=MapSpritePaletteTable
ldrb r0,[r1,r0]
bx r14



.align 4
UseCustomPaletteSlot_routine:
mov r1,0xA
lsl r1,r1,0x5
mov r2,0x20
lsl r2,r2,0x4
add r1,r1,r2
mov r2,0x20
ldr r3,=UseCustomPaletteSlot_return
mov r14,r1
ldr r3,=0x8001084
mov r15,r3
UseCustomPaletteSlot_return:
pop {r0,r1}
mov r0,0xA
bx r1

.pool


;-------------------------------------------------------------;

CustomHPBoxPalette_return:
cmp r0,0x0
beq StandardHPBoxPaletteCheck
pop {r1,r2}
b StandardHPBoxPaletteCheck_skip

StandardHPBoxPaletteCheck:
pop {r2}
lsr r0,r2,0x5
lsr r0,r0,0x1
lsl r0,0x2
ldr r1,=StandardHPBoxTable
ldr r0,[r1,r0]
pop {r2}
StandardHPBoxPaletteCheck_skip:
lsl r1,r2,0x5
mov r2,0x20
push {r4,r5}
ldr r4,=StandardHPBoxPaletteCheck_return+1
mov r14,r4
ldr r4,=0x8001084+1
mov r15,r4

StandardHPBoxPaletteCheck_return:
pop {r4,r5}
pop {r1}
bx r1
.pool


;-------------------------------------------------------------;

CustomBattleForecastPalette1_return:
cmp r0,0x0
bne ForecastPaletteCheck1_skip
ldr r0,=0x203A3F0
ldrb r0,[r0,0xB]
mov r1,0xC0
and r0,r1
ldr r1,=ForecastPaletteCheck1_skip+1
mov r14,r1
ldr r1,=0x8033B10
mov r15,r1

ForecastPaletteCheck1_skip:
mov r1,0x20
mov r2,0x20
ldr r3,=CustomBattleForecastDefender+1
mov r14,r3
ldr r3,=0x8001084
mov r15,r3

CustomBattleForecastDefender:
ldr r0,=0x203A470
mov r1,0x2
ldr r2,=CustomBattleForecastPalette2_return+1
mov r14,r2
ldr r2,=UniversalCustomPaletteCheck+1
mov r15,r2

CustomBattleForecastPalette2_return:
cmp r0,0x0
bne ForecastPaletteCheck2_skip
ldr r0,=0x203A470
ldrb r0,[r0,0xB]
mov r1,0xC0
and r0,r1
cmp r0,0x0
bne DefenderIsUnit
mov r0,0xC0
DefenderIsUnit:
ldr r1,=ForecastPaletteCheck2_skip+1
mov r14,r1
ldr r1,=0x8033B10
mov r15,r1

ForecastPaletteCheck2_skip:
mov r1,0x40
mov r2,0x20
ldr r3,=CustomBattleForecastDefender_return+1
mov r14,r3
ldr r3,=0x8001084
mov r15,r3
.pool


;-------------------------------------------------------------;



