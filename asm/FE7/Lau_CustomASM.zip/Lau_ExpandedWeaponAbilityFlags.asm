
;801727C - routine that pulls item abilities

LocalWeaponOffsetRetrieval:
mov r1,0xFF
and r0,r1
lsl r1,r0,0x3
add r1,r1,r0
lsl r1,r1,0x2
ldr r0,=address_ItemTable
add r1,r1,r0
bx r14

CheckEclipseApocalypse_damage:
;CheckImhulluStarlight:
ldr r0,[r4,0x4C]
mov r1,0x80
lsl r1,r1,0x10
and r0,r1
cmp r0,0x0
bne SkipImhulluCheck
ldr r0,[r6,0x4C]
mov r1,0x40
lsl r1,r1,0x10
and r0,r1
cmp r0,0x0
beq SkipImhulluCheck
mov r0,0x0
mov r1,r4
add r1,0x5A
strh r0,[r1]
mov r1,r6
add r1,0x5C
mov r0,0xFF
strh r0,[r1]
ldr r0,=0x8028F68+1
mov r15,r0

SkipImhulluCheck:
ldr r1,[r6]
ldr r1,[r1,0x28]
mov r2,0x10
lsl r2,r2,0x18
and r1,r2
cmp r1,0x0
beq SkipNegateApocEclipse
ldr r0,=0x8028F68+1
mov r15,r0

SkipNegateApocEclipse:
ldr r0,[r4,0x4C]
mov r1,r0
mov r2,0x8
lsl r2,r2,0x10
and r1,r2
cmp r1,0x0
beq noEclipse
mov r1,r0
mov r2,0x10
lsl r2,r2,0x10
and r1,r2
cmp r1,0x0
bne Damage_EclipseApocalypse 
b Damage_Eclipse
noEclipse:
mov r1,r0
mov r2,0x10
lsl r2,r2,0x10
and r1,r2
cmp r1,0x0
bne Damage_Apocalypse
ldr r0,=0x8028F68+1
mov r15,r0

Damage_EclipseApocalypse:
mov r0,0x13
ldsb r0,[r0,r6]
mov r1,r4
add r1,0x5A
strh r0,[r1]
ldr r0,=0x8028F58+1
mov r15,r0

Damage_Apocalypse:
mov r0,0x13
ldsb r0,[r0,r6]
sub r0,0x1
mov r1,r4
add r1,0x5A
strh r0,[r1]
ldr r0,=0x8028F58+1
mov r15,r0

Damage_Eclipse:
ldr r0,=0x8028F42+1
mov r15,r0
.pool


CheckCannotDouble_eclipse:
mov r1,0xFF
and r0,r1
lsl r1,r0,0x3
add r1,r1,r0
lsl r1,r1,0x2
ldr r0,=address_ItemTable
add r1,r1,r0
push {r1}
ldrb r0,[r1,0x1F]
cmp r0,0x0
beq SkipStatusInfliction
mov r1,r7
add r1,0x6F
strb r0,[r1]
ldr r0,[r6]
mov r1,0x40
ldrh r2,[r0]
orr r1,r2
strh r1,[r0]
SkipStatusInfliction:
pop {r0}
ldr r0,[r0,0x8]
mov r2,0x8
lsl r2,r2,0x18
and r0,r2
cmp r0,0x0
beq NoDoubleBan
ldr r0,=0x80293E0+1
mov r15,r0
NoDoubleBan:
ldr r0,=0x80293EE+1
mov r15,r0
.pool



CheckDevilReversal:
mov r1,0xFF
and r0,r1
lsl r1,r0,0x3
add r1,r1,r0
lsl r1,r1,0x2
ldr r0,=address_ItemTable
add r1,r1,r0
ldr r0,[r1,0x8]
mov r2,0x20
lsl r2,r2,0x10
and r0,r2
cmp r0,0x0
beq NoDevilReversal
ldr r0,=0x80293F8+1
mov r15,r0
NoDevilReversal:
ldr r0,=0x802943C+1
mov r15,r0
.pool



CheckLifesteal:
mov r1,0xFF
and r0,r1
lsl r1,r0,0x3
add r1,r1,r0
lsl r1,r1,0x2
ldr r0,=address_ItemTable
add r1,r1,r0
ldr r0,[r1,0x8]
mov r2,0x4
lsl r2,r2,0x10
and r0,r2
cmp r0,0x0
beq HasLifesteal
ldr r0,=0x8029468+1
mov r15,r0
HasLifesteal:
ldr r0,=0x802948E+1
mov r15,r0
.pool



CheckCanDouble:
mov r1,0xFF
and r0,r1
lsl r1,r0,0x3
add r1,r1,r0
lsl r1,r1,0x2
ldr r0,=address_ItemTable
add r1,r1,r0
ldr r0,[r1,0x8]
mov r2,0x8
lsl r2,r2,0x18
and r0,r2
cmp r0,0x0
bne DoublingDisabled
ldr r0,[r4,0x4]
add r0,0x4A
ldrh r0,[r0]
mov r1,0xFF
and r0,r1
lsl r1,r0,0x3
add r1,r1,r0
lsl r1,r1,0x2
ldr r0,=address_ItemTable
add r1,r1,r0
ldr r0,[r1,0x8]
mov r2,0x10
lsl r2,r2,0x18
and r0,r2
cmp r0,0x0
bne DoublingDisabled
mov r0,0x1
b DoublingFinal
DoublingDisabled:
mov r0,0x0
DoublingFinal:
pop {r4-r7}
pop {r1}
bx r1
.pool



WeaponTriangleFlags_routine:
ldr r0,[r4,0x4C]
mov r6,0x01
lsl r6,r6,0x18
and r0,r6
cmp r0,0x0
bne IgnoreWeaponTriangle
ldr r0,[r5,0x4C]
mov r6,0x01
lsl r6,r6,0x18
and r0,r6
cmp r0,0x0
bne IgnoreWeaponTriangle
mov r1,0x0
ldr r0,[r4,0x4C]
mov r6,0x80
lsl r6,r6,0x1
and r0,r6
cmp r0,0x0
beq noWeaponTriangleReversalA
add r1,0x1
noWeaponTriangleReversalA:
ldr r0,[r5,0x4C]
mov r6,0x80
lsl r6,r6,0x1
and r0,r6
cmp r0,0x0
beq noWeaponTriangleReversalB
add r1,0x1
noWeaponTriangleReversalB:
cmp r1,0x0
beq noWeaponTriangleReversalC
cmp r1,0x1
beq WeaponTriangleReversal
noWeaponTriangleReversalC:

ldr r0,[r4,0x4C]
mov r6,0x2
lsl r6,r6,0x18
and r0,r6
cmp r0,0x0
beq DoubleWeaponTriangleA
bl DoubleWeaponTriangle
DoubleWeaponTriangleA:
ldr r0,[r5,0x4C]
mov r6,0x2
lsl r6,r6,0x18
and r0,r6
cmp r0,0x0
beq NoDoubleWTA
bl DoubleWeaponTriangle
NoDoubleWTA:
pop {r4-r6}
pop {r0}
bx r0


IgnoreWeaponTriangle:
mov r1,r4
mov r2,0x0
IgnoreWeaponTriangle_loop:
add r1,0x53
mov r0,0x0
strb r0,[r1]
strb r0,[r1,0x1]
add r2,0x1
mov r1,r5
cmp r2,0x2
blt IgnoreWeaponTriangle_loop
b NoDoubleWTA

WeaponTriangleReversal:
mov r1,r4
mov r2,0x0
WeaponTriangleReversal_loop:
add r1,0x53
mov r0,0x0
ldsb r0,[r1,r0]
neg r0,r0
strb r0,[r1]
add r1,0x1
mov r0,0x0
ldsb r0,[r1,r0]
neg r0,r0
strb r0,[r1]
add r2,0x1
mov r1,r5
cmp r2,0x2
blt WeaponTriangleReversal_loop
b noWeaponTriangleReversalC

DoubleWeaponTriangle:
mov r1,r4
mov r2,0x0
DoubleWeaponTriangle_loop:
add r1,0x53
mov r0,0x0
ldsb r0,[r1,r0]
lsl r0,r0,0x1
strb r0,[r1]
add r1,0x1
mov r0,0x0
ldsb r0,[r1,r0]
lsl r0,r0,0x1
strb r0,[r1]
add r2,0x1
mov r1,r5
cmp r2,0x2
blt DoubleWeaponTriangle_loop
bx r14
.pool



CheckDecrementDurabilityMiss:
ldr r0,[r5,0x4C]
mov r1,0x80
lsl r1,r1,0x18
add r1,0x2
and r0,r1
cmp r0,0x0
bne AlwaysDecrementDurability
ldr r0,=0x80294C8+1
mov r15,r0
AlwaysDecrementDurability:
ldr r0,=0x80294AE+1
mov r15,r0
.pool



CheckForceRangeDistance:
mov r1,0x40
lsl r1,0x18
and r1,r0
cmp r1,0x0
bne ForceLongRange
mov r1,0x20
lsl r1,0x18
and r1,r0
cmp r1,0x0
bne ForceShortRange
NoForcedRange:
ldr r0,=0x8051FE4+1
mov r15,r0
ForceLongRange:
mov r0,0x2
strh r0,[r4]
b ForceRange_return
ForceShortRange:
mov r0,0x2
strh r0,[r4]
ForceRange_return:
ldr r0,=0x8052066+1
mov r15,r0
.pool


CheckCannotCritical:
mov r0,r4
ldr r1,[r0,0x4C]
mov r2,0x4
lsl r2,r2,0x18
and r1,r2
cmp r1,0x0
beq NormalCriticalRate
add r0,0x66
mov r1,0x0
strh r1,[r0]
add r0,0x4
strh r1,[r0]
NormalCriticalRate:
ldr r0,=0x8028544+1
mov r15,r0
.pool


CheckApocEclipse_dashDamage:
ldr r0,[r4,0x4C]
mov r1,0x18
lsl r1,0x10
and r0,r1
cmp r0,0x0
beq StandardDamageDisplay
ldr r1,=0x8028564+1
mov r15,r1
StandardDamageDisplay:
ldr r1,=0x802856C+1
mov r15,r1
.pool



