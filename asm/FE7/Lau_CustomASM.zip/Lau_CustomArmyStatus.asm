
StatusCheck_Rank:
mov r2,0x1
b CheckStatusTable

StatusCheck_Supports:
mov r2,0x2
;b CheckStatusTable

CheckStatusTable:
ldr r0,=0x202BC06
ldrb r0,[r0]
ldr r1,=ArmyStatusDataTable
ldrb r0,[r1,r0]
and r0,r2
cmp r0,0x0
beq RankCheckFalse
mov r0,0x1
RankCheckFalse:
bx r14

StatusCheck_Tactician:
ldr r0,=0x202BBF8
add r0,0x28
ldrb r0,[r0]
mov r1,0x1
and r0,r1
cmp r0,0x0
beq RankTacticianFalse
mov r0,0x1
RankTacticianFalse:
bx r14
.pool



