
ConditionalName_status:
push {r3,r4}
ldr r7,=0x200310C
ldr r0,[r7,0xC]
mov r4,r0
ldr r0,[r0]
ldrb r0,[r0,0x4]
mov r3,0x0
ldr r1,=ConditionalName_status_return1+1
mov r14,r1
ldr r1,=ConditionalNameCheck+1
mov r15,r1

ConditionalName_status_return1:
cmp r0,0x0
bne HasConditionalName_status
ldr r0,[r7,0xC]
ldr r0,[r0]
ldrh r0,[r0]
HasConditionalName_status:
pop {r3,r4}
ldr r1,=ConditionalName_status_return2+1
mov r15,r1



ConditionalName_HPBox:
push {r3,r4}
ldr r0,[r2]
mov r4,r2
ldrb r0,[r0,0x4]
mov r3,0x0
push {r2}
ldr r1,=ConditionalName_HPBox_return1+1
mov r14,r1
ldr r1,=ConditionalNameCheck+1
mov r15,r1

ConditionalName_HPBox_return1:
pop {r2}
cmp r0,0x0
bne HasConditionalName_HPBox
ldr r0,[r2]
ldrh r0,[r0]
HasConditionalName_HPBox:
pop {r3,r4}
ldr r1,=ConditionalName_HPBox_return2+1
mov r14,r1
ldr r1,=0x8012C60+1
mov r15,r1



ConditionalName_Chapter:
push {r3,r4}
ldr r0,[r4]
ldrb r0,[r0,0x4]
mov r3,0x0
push {r4}
ldr r1,=ConditionalName_Chapter_return1+1
mov r14,r1
ldr r1,=ConditionalNameCheck+1
mov r15,r1

ConditionalName_Chapter_return1:
pop {r4}
cmp r0,0x0
bne HasConditionalName_Chapter
ldr r0,[r4]
ldrh r0,[r0]
HasConditionalName_Chapter:
pop {r3,r4}
ldr r1,=ConditionalName_Chapter_return2+1
mov r14,r1
ldr r1,=0x8012C60+1
mov r15,r1



ConditionalName_Unit:
push {r3,r4}
push {r0}
mov r4,r0
ldr r0,[r0]
ldrb r0,[r0,0x4]
mov r3,0x0
ldr r1,=ConditionalName_Unit_return1+1
mov r14,r1
ldr r1,=ConditionalNameCheck+1
mov r15,r1

ConditionalName_Unit_return1:
pop {r1}
cmp r0,0x0
bne HasConditionalName_Unit
ldr r0,[r1]
ldrh r0,[r0]
HasConditionalName_Unit:
pop {r3,r4}
ldr r1,=ConditionalName_Unit_return2+1
mov r14,r1
ldr r1,=0x8012C60+1
mov r15,r1



ConditionalName_Forecast:
push {r3,r4}
push {r2}
mov r4,r2
ldr r0,[r2]
ldrb r0,[r0,0x4]
mov r3,0x0
ldr r1,=ConditionalName_Forecast_return1+1
mov r14,r1
ldr r1,=ConditionalNameCheck+1
mov r15,r1

ConditionalName_Forecast_return1:
pop {r2}
cmp r0,0x0
bne HasConditionalName_Forecast
ldr r0,[r2]
ldrh r0,[r0]
HasConditionalName_Forecast:
pop {r3,r4}
ldr r1,=ConditionalName_Forecast_return2+1
mov r14,r1
ldr r1,=0x8012C60+1
mov r15,r1



ConditionalName_Battle:
push {r3,r4}
push {r0}
mov r4,r0
ldr r0,[r0]
ldrb r0,[r0,0x4]
mov r3,0x0
ldr r1,=ConditionalName_Battle_return1+1
mov r14,r1
ldr r1,=ConditionalNameCheck+1
mov r15,r1

ConditionalName_Battle_return1:
pop {r1}
cmp r0,0x0
bne HasConditionalName_Battle
ldr r0,[r1]
ldrh r0,[r0]
HasConditionalName_Battle:
pop {r3,r4}
ldr r1,=ConditionalName_Battle_return2+1
mov r14,r1
ldr r1,=0x8012C60+1
mov r15,r1



ConditionalName_Trade:
push {r3,r4}
push {r1}
mov r4,r1
ldr r0,[r1]
ldrb r0,[r0,0x4]
mov r3,0x0
ldr r1,=ConditionalName_Trade_return1+1
mov r14,r1
ldr r1,=ConditionalNameCheck+1
mov r15,r1

ConditionalName_Trade_return1:
pop {r1}
cmp r0,0x0
bne HasConditionalName_Trade
ldr r0,[r1]
ldrh r0,[r0]
HasConditionalName_Trade:
pop {r3,r4}
ldr r1,=ConditionalName_Trade_return2+1
mov r14,r1
ldr r1,=0x8012C60+1
mov r15,r1



ConditionalName_TradeMenu:
push {r3,r4}
ldr r0,[r2,0x30]
push {r0}
mov r4,r0
ldr r0,[r1]
ldrb r0,[r0,0x4]
mov r3,0x0
ldr r1,=ConditionalName_TradeMenu_return1+1
mov r14,r1
ldr r1,=ConditionalNameCheck+1
mov r15,r1

ConditionalName_TradeMenu_return1:
pop {r1}
cmp r0,0x0
bne HasConditionalName_TradeMenu
ldr r0,[r1]
ldrh r0,[r0]
HasConditionalName_TradeMenu:
pop {r3,r4}
ldr r1,=0x802AC6A+1
mov r14,r1
ldr r1,=0x8012C60+1
mov r15,r1



ConditionalName_StaffTarget:
push {r3,r4}
ldr r0,[r4,0x2C]
push {r0}
mov r4,r0
ldr r0,[r1]
ldrb r0,[r0,0x4]
mov r3,0x0
ldr r1,=ConditionalName_StaffTarget_return1+1
mov r14,r1
ldr r1,=ConditionalNameCheck+1
mov r15,r1

ConditionalName_StaffTarget_return1:
pop {r1}
cmp r0,0x0
bne HasConditionalName_StaffTarget
ldr r0,[r1]
ldrh r0,[r0]
HasConditionalName_StaffTarget:
pop {r3,r4}
ldr r1,=0x80316C6+1
mov r14,r1
ldr r1,=0x8012C60+1
mov r15,r1



ConditionalName_BattleMap1:
push {r3,r4}
ldr r1,[r0]
mov r4,r1
push {r1}
ldr r0,[r1]
ldrb r0,[r0,0x4]
mov r3,0x0
ldr r1,=ConditionalName_BattleMap1_return1+1
mov r14,r1
ldr r1,=ConditionalNameCheck+1
mov r15,r1

ConditionalName_BattleMap1_return1:
pop {r1}
cmp r0,0x0
bne HasConditionalName_BattleMap1
ldr r0,[r1]
ldrh r0,[r0]
HasConditionalName_BattleMap1:
pop {r3,r4}
ldr r1,=0x806FCDC+1
mov r15,r1



ConditionalName_Battle2:
push {r3,r4}
push {r0}
mov r4,r0
ldr r0,[r0]
ldrb r0,[r0,0x4]
mov r3,0x0
ldr r1,=ConditionalName_Battle2_return1+1
mov r14,r1
ldr r1,=ConditionalNameCheck+1
mov r15,r1

ConditionalName_Battle2_return1:
pop {r1}
cmp r0,0x0
bne HasConditionalName_Battle2
ldr r0,[r1]
ldrh r0,[r0]
HasConditionalName_Battle2:
pop {r3,r4}
ldr r1,=ConditionalName_Battle2_return2+1
mov r14,r1
ldr r1,=0x8012C60+1
mov r15,r1
.pool



ConditionalDesc_status:
push {r1,r3,r4}
push {r14}
ldr r4,[r0,0xC]
ldr r0,[r4]
ldrb r0,[r0,0x4]
mov r3,0x2
ldr r1,=ConditionalDesc_status_return1+1
mov r14,r1
ldr r1,=ConditionalNameCheck+1
mov r15,r1

ConditionalDesc_status_return1:
cmp r0,0x0
bne SkipGenericDescriptionGet
ldr r0,[r4]
ldrh r0,[r0,0x2]
SkipGenericDescriptionGet:
pop {r1}
mov r14,r1
pop {r1,r3,r4}
cmp r0,0x0
beq NoMessagesForThisMenuItem
ldr r2,=ConditionalDesc_status_return2+1
mov r15,r2
NoMessagesForThisMenuItem:
ldr r2,=0x8081718+1
mov r15,r2



.pool






ConditionalNameCheck:
ldr r1,=ConditionalUnitTextTable
ConditionalNameCheck_loop:
ldrb r2,[r1]
cmp r2,0x0
beq NoConditionalName
cmp r0,r2
beq HasConditionalName
add r1,0x14
b ConditionalNameCheck_loop
NoConditionalName:
;ldr r0,=0x200310C
;ldr r0,[r0,0xC]
;ldr r0,[r0]
;ldrh r0,[r0]
mov r0,0x0
bx r14
.pool

HasConditionalName:
add r1,0x4
ldrh r2,[r1,r3]
cmp r2,0x0
beq NoConditionalName
sub r1,0x4
ldrb r2,[r1,0x8]
cmp r2,0x0
beq NoMapCheck
cmp r2,0xFF
beq NoMapCheck
ldr r0,=0x202BC06
ldrb r0,[r0]
cmp r2,r0
bne NoConditionalName

NoMapCheck:
ldrb r2,[r1,0x9]
cmp r2,0x0
beq NoFactionCheck
cmp r2,0xFF
beq NoFactionCheck
cmp r2,0x10
bge NoConditionalName
ldr r0,=ConditionalNameFactionTable
lsl r2,r2,0x2
ldr r0,[r0,r2]
ldrb r2,[r4,0xB]
mov r15,r0


NoFactionCheck:
ldrb r2,[r1,0xA]
cmp r2,0x0
beq NoClassCheck
cmp r2,0xFF
beq NoClassCheck
ldr r0,=0x200310C
ldr r0,[r0,0xC]
ldr r0,[r0,0x4]
ldrb r0,[r0,0x4]
cmp r2,r0
bne NoConditionalName

NoClassCheck:
ldrb r2,[r1,0xB]
cmp r2,0x0
beq NoModeCheck
cmp r2,0xFF
beq NoModeCheck
ldr r0,=0x202BC06
ldrb r0,[r0,0xD]
cmp r2,r0
bne NoConditionalName

NoModeCheck:
ldrh r0,[r1,0xC]
cmp r0,0x0
beq NoFlagOnCheck
push {r1,r14}
ldr r2,=uctc_flag_return1+1
mov r14,r2
ldr r2,=0x80798F8+1
mov r15,r2
uctc_flag_return1:
pop {r1,r2}
mov r14,r2
cmp r0,0x0
beq NoConditionalName

NoFlagOnCheck:
ldrh r0,[r1,0xC]
cmp r0,0x0
beq NoFlagOffCheck
push {r1,r14}
ldr r2,=uctc_flag_return2+1
mov r14,r2
ldr r1,=0x80798F8+1
mov r15,r2
uctc_flag_return2:
pop {r1,r2}
mov r14,r2
cmp r0,0x0
bne NoConditionalName

NoFlagOffCheck:
ldr r0,[r1,0x10]
cmp r0,0x0
beq NoCustomASMCheck
push {r1,r14}
ldr r2,=CustomASMCheck_return
mov r14,r2
mov r15,r0
CustomASMCheck_return:
pop {r1,r2}
mov r14,r2
cmp r0,0x0
beq NoConditionalName

NoCustomASMCheck:
add r1,0x4
ldrh r0,[r1,r3]
bx r14
.pool

ConditionalNameFactionTable:
.dw NoClassCheck+1
.dw CUTCheck_Player+1
.dw CUTCheck_Enemy+1
.dw CUTCheck_PlayerEnemy+1
.dw CUTCheck_NPC+1
.dw CUTCheck_PlayerNPC+1
.dw CUTCheck_EnemyNPC+1
.dw CUTCheck_PlayerEnemyNPC+1
.dw CUTCheck_Other+1
.dw CUTCheck_OtherPlayer+1
.dw CUTCheck_OtherEnemy+1
.dw CUTCheck_OtherPlayerEnemy+1
.dw CUTCheck_OtherNPC+1
.dw CUTCheck_OtherPlayerNPC+1
.dw CUTCheck_OtherEnemyNPC+1
.dw NoClassCheck+1

CUTCheck_Player:
cmp r2,0x40
blt uctf_true
b uctf_false

CUTCheck_Enemy:
cmp r2,0x80
blt uctf_false
cmp r2,0xC0
blt uctf_true
b uctf_false

CUTCheck_PlayerEnemy:
cmp r2,0x40
blt uctf_true
cmp r2,0xC0
blt uctf_true
b uctf_false

CUTCheck_NPC:
cmp r2,0x40
blt uctf_false
cmp r2,0x80
bge uctf_false
b uctf_false

CUTCheck_PlayerNPC:
cmp r2,0x80
blt uctf_true
b uctf_false

CUTCheck_EnemyNPC:
cmp r2,0x40
blt uctf_false
cmp r2,0xC0
bge uctf_false
b uctf_true

CUTCheck_PlayerEnemyNPC:
cmp r2,0xC0
blt uctf_true
b uctf_false

CUTCheck_Other:
cmp r2,0xC0
bge uctf_true
b uctf_false

CUTCheck_OtherPlayer:
cmp r2,0x40
blt uctf_true
cmp r2,0xC0
bge uctf_true
b uctf_false

CUTCheck_OtherEnemy:
cmp r2,0x80
bge uctf_true
b uctf_false

CUTCheck_OtherPlayerEnemy:
cmp r2,0x80
bge uctf_true
cmp r2,0x40
blt uctf_true
b uctf_false

CUTCheck_OtherNPC:
cmp r2,0xC0
bge uctf_true
cmp r2,0x40
blt uctf_false
cmp r2,0x80
blt uctf_true
b uctf_false

CUTCheck_OtherPlayerNPC:
cmp r2,0xC0
bge uctf_true
cmp r2,0x40
blt uctf_false
b uctf_false

CUTCheck_OtherEnemyNPC:
cmp r2,0x40
bge uctf_true
b uctf_false


uctf_true:
ldr r2,=NoFactionCheck+1
mov r15,r2
.pool
uctf_false:
ldr r2,=NoConditionalName+1
mov r15,r2
.pool

