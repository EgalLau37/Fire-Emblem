
ModeEliwoodCheck:
ldr r0,=ForcedDeploymentTable
cmp r4,0x1
beq ForceDeployment
cmp r4,0x2
beq ForceDeployment
ModeZeroCheck:
ModeLynCheck:
ModeHectorCheck:
mov r0,0x0
b DeploymentCheckEnd
ForceDeployment:
mov r0,0x1

DeploymentCheckEnd:
pop {r4}
pop {r1}
bx r1