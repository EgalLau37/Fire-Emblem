
.org 0x808DD78
push {r4,r14}
mov r4,r0
bl 0x803DA14
lsl r0,r0,0x18
cmp r0,0x0
bne ModeZeroCheck
ldr r0,=0x202BC06
ldrb r1,[r0,0xD]
lsl r1,r1,0x2
ldr r0,=ForcedDeploymentRoutineTable
ldr r0,[r0,r1]
mov r15,r0
.pool

ForcedDeploymentRoutineTable:
.dw ModeZeroCheck+1
.dw ModeLynCheck+1
.dw ModeEliwoodCheck+1
.dw ModeHectorCheck+1




