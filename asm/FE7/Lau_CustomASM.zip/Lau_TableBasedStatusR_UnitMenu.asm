
.org 0x8081504
ldr r2,=0x200310C
ldr r0,[r2,0x14]
cmp r0,0x0
bne StatusPointerAlreadySet
ldr r0,=StatusRMenuTable
lsl r1,r4,0x2
add r0,r0,r1
ldr r0,[r0]
str r0,[r2,0x14]
StatusPointerAlreadySet:
mov r1,r5
bl 0x8081C94
pop {r4,r5}
pop {r0}
bx r0
.pool

StatusRMenuTable:
.dw 0x8CC2140
.dw 0x8CC231C
.dw 0x8CC2434
.dw BiographyPageRMenuList

