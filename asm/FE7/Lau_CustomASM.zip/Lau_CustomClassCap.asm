
CustomLevelCapCheck:
strb r0,[r7,0x8]
ldr r1,[r7,0x4]
ldrb r1,[r1,0x4]
ldr r3,=CustomLevelCapTable
ldrb r1,[r3,r1]
cmp r0,r1
bge CustomLevelCapHit
ldr r1,=0x80296A4+1
mov r15,r1
CustomLevelCapHit:
ldr r1,=0x8029696+1
mov r15,r1
.pool

