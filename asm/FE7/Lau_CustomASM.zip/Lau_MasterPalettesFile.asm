

.org 0x80256F4	;map sprites
push {r14}
push {r0}
mov r1,0x0
ldr r2,=CustomMapSpritePalette_return+1
mov r14,r2
ldr r2,=UniversalCustomPaletteCheck+1
mov r15,r2
.pool

MapSpritePaletteTable:
.db 0xC
.db 0xE
.db 0xD
.db 0xB
.db 0xF

;-------------------------------------------------------------;

.org 0x8084E28	;HP box
push {r14}
push {r0,r1}
mov r0,r8
mov r1,0x1
ldr r2,=CustomHPBoxPalette_return+1
mov r14,r2
ldr r2,=UniversalCustomPaletteCheck+1
mov r15,r2
.pool

StandardHPBoxTable:
.dw 0x840453C
.dw 0x840457C
.dw 0x840455C
.dw 0x840459C

;-------------------------------------------------------------;

.org 0x8033B48	;battle forecast, right/attacker
push {r4,r14}
ldr r0,=0x203A3F0
mov r1,0x2
ldr r2,=CustomBattleForecastPalette1_return+1
mov r14,r2
ldr r2,=UniversalCustomPaletteCheck+1
mov r15,r2
.pool

CustomBattleForecastDefender_return:
pop {r4}
pop {r0}
bx r0

;-------------------------------------------------------------;

.org 0x806FB4C
push {r14}
push {r0}
mov r1,0x3
ldr r2,=CustomMapBattleStats_return+1
mov r14,r2
ldr r2,=UniversalCustomPaletteCheck+1
mov r15,r2

CustomMapBattleStats_return:
pop {r1}
cmp r0,0x0
bne StandardMapBattleStatsPaletteCheck_skip
ldrb r0,[r1,0xB]
cmp r0,0x0
bne MapBattleStatsIsUnit
mov r0,0x4
b MapBattleStatsOther
MapBattleStatsIsUnit:
lsr r0,r0,0x5
lsr r0,r0,0x1
MapBattleStatsOther:
lsl r0,r0,0x2
ldr r1,=MapBattleStatsPaletteTable
ldr r0,[r1,r0]
StandardMapBattleStatsPaletteCheck_skip:
pop {r1}
bx r1
.pool

.align 4
MapBattleStatsPaletteTable:
.dw 0x83F41CC
.dw 0x83F420C
.dw 0x83F41EC
.dw 0x83F422C

