
.org 0x8052D40
.fill 0x78,0x69
.org 0x8052D40
ldr r1,=RangedIDTable
ForceRange_L_loop:
ldrb r2,[r1]
cmp r2,0x0
beq NoForceRanged_L
cmp r0,r2
beq ForceRanged_L
add r1,0x1
b ForceRange_L_loop
ForceRanged_L:
mov r0,0x1
str r0,[r13,0x14]
NoForceRanged_L:
ldr r5,[r13,0x8]
add r5,0x4A
ldrh r0,[r5]
bl 0x80171B4

ldr r1,=RangedIDTable
ForceRange_R_loop:
ldrb r2,[r1]
cmp r2,0x0
beq NoForceRanged_R
cmp r0,r2
beq ForceRanged_R
add r1,0x1
b ForceRange_R_loop
ForceRanged_R:
mov r0,0x1
str r0,[r13,0x18]
NoForceRanged_R:
b 0x8052DBA
.pool


