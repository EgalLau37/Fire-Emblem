
.org 0x807FA8C	;status screen
push {r4-r7,r14}
mov r7,r8
push {r7}
add r13,-0x8
ldr r0,=ConditionalName_status+1
mov r15,r0
.pool
ConditionalName_status_return2:

.org 0x8085134	;HP box
ldr r0,=ConditionalName_HPBox+1
mov r15,r0
.pool
ConditionalName_HPBox_return2:

.org 0x8086CB4	;chapter screen
ldr r0,=ConditionalName_Chapter+1
mov r15,r0
.pool
ConditionalName_Chapter_return2:

.org 0x808ADBC	;unit screen
ldr r1,=ConditionalName_Unit+1
mov r15,r1
.pool
ConditionalName_Unit_return2:

.org 0x803346C	;battle forecast
ldr r0,=ConditionalName_Forecast+1
mov r15,r0
.pool
ConditionalName_Forecast_return2:

.org 0x804D2F4
ldr r1,=ConditionalName_Battle+1
mov r15,r1
.pool
ConditionalName_Battle_return2:

.org 0x80317D8
ldr r0,=ConditionalName_Trade+1
mov r15,r0
.pool
ConditionalName_Trade_return2:

.org 0x802AC60
ldr r0,=ConditionalName_TradeMenu+1
mov r15,r0
.pool
ConditionalName_TradeMenu_return2:

.org 0x80316BC
ldr r0,=ConditionalName_StaffTarget+1
mov r15,r0
.pool
ConditionalName_StaffTarget_return2:

.org 0x806FCD4
ldr r1,=ConditionalName_BattleMap1+1
mov r15,r1
.pool
ConditionalName_BattleMap1_return2:

.org 0x804D234
ldr r1,=ConditionalName_Battle2+1
mov r15,r1
.pool
ConditionalName_Battle2_return2:



.org 0x8081700
ldr r2,=ConditionalDesc_status+1
mov r15,r2
.pool
mov r3,r3
mov r3,r3
ConditionalDesc_status_return2:
add r1,0x4C
strh r0,[r1]
bx r14
