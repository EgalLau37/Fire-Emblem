
PreCharacterStatistics:
push {r14}
ldr r0,=PreCharacterStatistics_return+1
mov r14,r0
ldr r0,=UniversalPageClear+1
mov r15,r0
PreCharacterStatistics_return:
ldr r0,=PreCharacterStatistics_return2+1
mov r14,r0
ldr r0,=0x807FDF0+1
mov r15,r0
PreCharacterStatistics_return2:
pop {r0}
bx r0


PreCharacterEquipment:
push {r14}
ldr r0,=PreCharacterEquipment_return+1
mov r14,r0
ldr r0,=UniversalPageClear+1
mov r15,r0
PreCharacterEquipment_return:
ldr r0,=PreCharacterEquipment_return2+1
mov r14,r0
ldr r0,=0x80800B4+1
mov r15,r0
PreCharacterEquipment_return2:
pop {r0}
bx r0


PreCharacterRanks:
push {r14}
ldr r0,=PreCharacterRanks_return+1
mov r14,r0
ldr r0,=UniversalPageClear+1
mov r15,r0
PreCharacterRanks_return:
ldr r0,=PreCharacterRanks_return2+1
mov r14,r0
ldr r0,=0x8080424+1
mov r15,r0
PreCharacterRanks_return2:
pop {r0}
bx r0
.pool


UniversalPageClear:
push {r14}
ldr r0,=0x2028D58
ldr r1,=0x6001000
mov r2,0x80
mov r3,0x0
ldr r4,=ReturnPageClear1+1
mov r14,r4
ldr r4,=0x80053D4+1;3B0+1;
mov r15,r4
ReturnPageClear1:
ldr r1,=0x2028D78
mov r0,0xFF
strb r0,[r1]
ldr r0,=ReturnPageClear2+1
mov r14,r0
ldr r0,=0x8004CE8+1
mov r15,r0
ReturnPageClear2:
ldr r0,=0x2028D70
ldr r0,[r0]
mov r1,0xE
strb r1,[r0,0x12]
ldr r0,=ClearGraphicsTable
ldr r1,=ReturnPageClear3+1	;clears RAM area for text graphics
mov r14,r1
ldr r1,=0x80054C4+1
mov r15,r1
ReturnPageClear3:
ldr r0,=0x2028D58
ldr r1,=0x6001000
str r1,[r0]
pop {r0}
bx r0
.pool


