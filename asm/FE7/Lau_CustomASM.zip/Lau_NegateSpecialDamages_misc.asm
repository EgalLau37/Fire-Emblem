
.org 0x8028F74
ldr r1,=CheckNegateLuna+1
mov r15,r1
.pool



