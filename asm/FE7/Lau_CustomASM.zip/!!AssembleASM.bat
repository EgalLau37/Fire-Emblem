@echo off

armips.exe !MasterFile.asm -sym ASMDirectory.asm

pause