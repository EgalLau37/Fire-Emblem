
.align 0x10
ArmyStatusDataTable:
.import "_ArmyStatusTable.bin"

.align 4
RangedIDTable:
.db 0x11
.db 0x28
.db 0x29
.db 0x0	;terminator

.align 4
AffinityTextsTable:
.dh 0x26F
.dh 0x1AE
.dh 0x1AD
.dh 0x1AC
.dh 0x1AB
.dh 0x1AA
.dh 0x1A9
.dh 0x1A8




.align 4
WeaponOverrideTable:
.db 0x10	;item
.db 0x6		;type
.db 0x0		;range condition for override
.db 0x0		;damage type

.db 0x11
.db 0x7
.db 0x0
.db 0x0

.db 0x99
.db 0x5
.db 0x0
.db 0x0

.dw 0x0	;terminator



.align 4
CustomLevelCapTable:
.import "_CustomLevelCapTable.bin"



.align 4
OptionDataTable:
.import "_OptionDataTable.bin"
.dw CasualModeOption
OptionDisplayTable:
.import "_OptionDisplayTable.bin"
.dw CasualModeOption_display



.align 0x10
.include	"_ConditionalUnitTextsTable.asm"



CustomPalettesTable:
.dh 0x1
.dh 0x0
.dw 0x0
.dw 0x0
.dw PaletteList_Lau

.dh 0x2
.dh 0xF
.dw 0x0
.dw 0x0
.dw PaletteList_Brandon

.dw 0x0	;terminator



