
.open 	"FE7U.gba", "FE7U_2.gba", 0x8000000	
.gba
.thumb

.include 	"Definitions.asm"
freespace_customASM	equ	0x9000000
address_ItemTable	equ 0x8BE222C

Lau_CharacterBiography		equ "true"
Lau_WeaponAbilities			equ "true"
Lau_CustomArmyStatus		equ "true"
Lau_ForceRangeAnimation		equ "true"
Lau_WeaponTypeOverride		equ "true"
;Lau_ForcedDeployment		equ "true"
Lau_NegateSpecialEffects	equ "true"
Lau_PerAffinityTexts		equ "true"
Lau_AIActionExpansion		equ "true"
Lau_CasualModeOption		equ "true"
Lau_ConditionalUnitTexts	equ "true"
Lau_CustomLevelCap			equ "true"
Lau_CustomUnitPalettes		equ "true"

;below is a switch for the uncounterable flag:
;if set to "attackerOnly", the uncounterable flag only checks
;if the attacker has the flag for preventing counters:
;A player attacking into an enemy with an uncounterable weapon yields
;a normal battle; however, if that enemy attacked back on its turn,
;the player unit will not be able to counter back.
;By default, the game checks both players to determine whether a
;round of combat should have counters at all.
;Leave as "vanilla" for vanilla behavior.
;parameters are: "vanilla", "attackerOnly", and "defenderOnly"

UncounterableCheck	equ	"vanilla"


.if Lau_CharacterBiography == "true"
.include	"Lau_TableBasedStatusR_UnitMenu.asm"
.org 0x80811BC	;number of pages
mov r0,0x4

.org 0x80804F6
.dh 0x4904
.org 0x8080508
.dw PageCodePointerTable
.org 0x8080ACC
.dw PageHeaderGraphicTable
.endif


.if Lau_WeaponAbilities	 == "true"
.include	"Lau_ExpandedWeaponAbilityFlags_misc.asm"
.endif
.if Lau_CustomArmyStatus == "true"
.include	"Lau_CustomArmyStatus_misc.asm"
.endif
.if Lau_ForceRangeAnimation == "true"
.include	"Lau_ForceRangedAnimation.asm"
.endif
.if Lau_WeaponTypeOverride == "true"
.include	"Lau_WeaponTypeOverride_misc.asm"
.endif

.if Lau_NegateSpecialEffects == "true"
.include	"Lau_NegateSpecialDamages_misc.asm"
.endif
.if Lau_ConditionalUnitTexts == "true"
.include	"Lau_UnitConditionalTexts_misc.asm"
.endif
.if Lau_PerAffinityTexts == "true"
.org 0x8CC2270
.dw LauAffinityTextDisplay+1
.endif
.if Lau_AIActionExpansion == "true"
.org 0x80385DA
ldr r0,=ExtraAIStealCheck+1
mov r15,r0
.pool
.endif

.if Lau_CasualModeOption == "true"
.org 0x80AE4D4
cmp r0,0x10		;max number of options
.org 0x80AE4E4
.dw OptionDataTable
.org 0x8C7825C

.org 0x80AE366
cmp r0,0x10
.org 0x80AE378
.dw OptionDisplayTable
.endif

.if Lau_CustomLevelCap == "true"
.org 0x802968C
ldr r1,=CustomLevelCapCheck+1
mov r15,r1
.pool
.endif

.if Lau_CustomUnitPalettes == "true"
.include	"Lau_MasterPalettesFile.asm"
.endif


.org freespace_customASM

.if Lau_CharacterBiography == "true"
PageCodePointerTable:
.dw PreCharacterStatistics+1	;0x807FDF0+1	;character statistics
.dw PreCharacterEquipment+1	;0x80800B4+1	;character equipment
.dw PreCharacterRanks+1	;0x8080804+1	;character ranks
.dw CharacterPage_Biography+1	;character information
.dw 0x0

.align 0x10
ClearGraphicsTable:
.import "ClearGraphics.bin"

PageHeaderGraphicTable:
.dh 0x14
.dh 0x8
.dh 0x54
.dh 0x14

.include	"Lau_ExtraInfoPage.asm"			;main code
.include	"Lau_ExtraPageInfo_Extra.asm"	;extra code to clear OAM
.include	"Lau_StatusRMenuTable.asm"		;data for R-button help descriptions

.include	"CharacterInfo.asm"				;character info table
.endif


.if Lau_WeaponAbilities == "true"
.align 4
.include	"Lau_ExpandedWeaponAbilityFlags.asm"
.endif
.if Lau_CustomArmyStatus == "true"
.align 4
.include	"Lau_CustomArmyStatus.asm"
.endif
.if Lau_WeaponTypeOverride == "true"
.align 4
.include	"Lau_WeaponTypeOverride.asm"
.endif

.if Lau_NegateSpecialEffects == "true"
.align 4
.include	"Lau_NegateSpecialDamages.asm"
.endif
.if Lau_ConditionalUnitTexts == "true"
.align 4
.include	"Lau_ConditionalUnitTexts.asm"
.endif
.if Lau_AIActionExpansion == "true"
.align 4
.include	"Lau_AIActionExpansion.asm"
.endif
.if Lau_PerAffinityTexts == "true"
.align 4
.include	"Lau_PerAffinityDescriptions.asm"
.endif
.if Lau_CasualModeOption == "true"
.align 4
.include	"Lau_CasualModeOption.asm"
.endif
.if Lau_CustomLevelCap == "true"
.align 4
.include	"Lau_CustomClassCap.asm"
.endif

.if Lau_CustomUnitPalettes == "true"
.align 4
.include	"Lau_UniversalPalettesRoutine.asm"
.include	"Lau_CustomUnitGUIPalettes.asm"

.include	"_CustomPalettesTable.asm"
.endif

.include	"DataTables.asm"



.close

