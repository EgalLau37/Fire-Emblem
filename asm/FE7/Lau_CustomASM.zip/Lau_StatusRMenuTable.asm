
BiographyPageRMenuList:
;likes
Biography_Likes:
.dw 0x0;up
.dw Biography_Dislikes;down
.dw Biography_CharDesc;left
.dw 0x0;right
.db 102;x
.db 24;y
.dh 0xB06;text ID
.dw 0x0;loop
.dw 0x0;unique data retrieval

Biography_Dislikes:
.dw Biography_Likes;up
.dw Biography_Age;down
.dw Biography_CharDesc;left
.dw 0x0;right
.db 102;x
.db 56;y
.dh 0xB07;text ID
.dw 0x0;loop
.dw 0x0;unique data retrieval

Biography_Age:
.dw Biography_Dislikes;up
.dw Biography_Affiliation;down
.dw Biography_CharDesc;left
.dw Biography_Height;right
.db 102;x
.db 88;y
.dh 0xB08;text ID
.dw 0x0;loop
.dw 0x0;unique data retrieval

Biography_Height:
.dw Biography_Dislikes;up
.dw Biography_Affiliation;down
.dw Biography_Age;left
.dw 0x0;right
.db 166;x
.db 88;y
.dh 0xB09;text ID
.dw 0x0;loop
.dw 0x0;unique data retrieval

Biography_Affiliation:
.dw Biography_Age;up
.dw 0x0;down
.dw Biography_ClassDesc;left
.dw 0x0;right
.db 110;x
.db 104;y
.dh 0xB0A;text ID
.dw 0x0;loop
.dw 0x0;unique data retrieval


Biography_CharDesc:
.dw 0x0
.dw Biography_ClassDesc
.dw 0x0
.dw Biography_Age
.db 40
.db 80
.dh 0x0
.dw 0x0;loop
.dw 0x80816FD


Biography_ClassDesc:
.dw Biography_CharDesc
.dw Biography_Level
.dw 0x0
.dw Biography_Affiliation
.db 6
.db 104
.dh 0x22B
.dw 0x0;loop
.dw 0x8081725

Biography_Level:
.dw Biography_ClassDesc
.dw Biography_HP
.dw 0x0
.dw Biography_EXP
.db 6
.db 120
.dh 0x25B
.dw 0x0;loop
.dw 0x0

Biography_HP:
.dw Biography_Level
.dw 0x0
.dw 0x0
.dw Biography_Affiliation
.db 6
.db 136
.dh 0x25D
.dw 0x0;loop
.dw 0x0

Biography_EXP:
.dw Biography_ClassDesc
.dw Biography_HP
.dw Biography_Level
.dw Biography_Affiliation
.db 38
.db 120
.dh 0x25C
.dw 0x0;loop
.dw 0x0

