
.org 0x808DF2C
ldr r2,=0x202BBF8
mov r0,0x80
ldrb r3,[r2,0x14]
and r0,r3
cmp r0,0x0
bne NotMainPrepScreen
mov r4,0x0
mov r5,r1
CheckAnotherStatusFlag:
mov r0,r4
bl 0x80991F8
lsl r0,r0,0x18
cmp r0,0x0
beq StatusFlagOff
mov r0,0x1
lsl r0,r4
ldrb r1,[r5]
orr r0,r1
strb r0,[r5]

StatusFlagOff:
add r4,0x1
cmp r4,0x3
ble CheckAnotherStatusFlag
ldr r1,=0x808DBBD
ldr r3,=0x1146
mov r0,0x0
str r0,[r13]
mov r0,0x4
mov r2,0x0
bl 0x808FEC0
NotMainPrepScreen:
add r13,0x4
pop {r4-r6}
pop {r0}
bx r0
.pool


.org 0x80991F8
ldr r1,=ArmyStatusRoutineTable
lsl r0,r0,0x2
ldr r0,[r1,r0]
ldr r1,=StatusCheck_return+1
mov r15,r0
StatusCheck_return:
bx r14
.pool

ArmyStatusRoutineTable:
.dw StatusCheck_Rank+1
.dw StatusCheck_Tactician+1
.dw 0x80992F4+1;StatusCheck_Augury
.dw StatusCheck_Supports+1







