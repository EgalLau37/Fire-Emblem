
PaletteList_Lau:
.dw MapSprite_Lau
.dw HPBox_Lau
.dw Forecast_Lau
.dw MapBattleStats_Lau

PaletteList_Brandon:
.dw 0xD
.dw HPBox_Brandon
.dw Forecast_Brandon
.dw MapBattleStats_Brandon

MapSprite_Lau:
.import "palettes/MapSprite_Lau.bin"

HPBox_Lau:
.import "palettes/HPBox_Lau.bin"

Forecast_Lau:
.import "palettes/Forecast_Lau.bin"

MapBattleStats_Lau:
.import "palettes/MapBattleStats_Lau.bin"


HPBox_Brandon:
.import "palettes/HPBox_Brandon.dmp"

Forecast_Brandon:
.import "palettes/Forecast_Brandon.dmp"

MapBattleStats_Brandon:
.import "palettes/MapBattleStats_Brandon.dmp"
