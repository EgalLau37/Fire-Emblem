
LauAffinityTextDisplay:
ldr r1,=0x200310C
ldr r1,[r1,0xC]
ldr r1,[r1]
ldrb r1,[r1,0x9]
ldr r0,=AffinityTextsTable
lsl r1,r1,0x1
ldrh r1,[r0,r1]
mov r0,r4
add r0,0x4C
strh r1,[r0]
bx r14
.pool

