
CheckNegateLuna:
ldr r1,[r6]
ldr r1,[r1,0x28]
mov r2,0x10
lsl r2,r2,0x18
and r1,r2
cmp r1,0x0
bne SkipNegateLuna
mov r1,r6
add r1,0x5C
mov r0,0x0
strh r0,[r1]
SkipNegateLuna:
pop {r4-r6}
pop {r0}
bx r0
.pool


