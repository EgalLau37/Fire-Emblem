
CasualModeOption:
cmp r3,0x0
beq OffCasualMode
cmp r3,0x1
beq SetCasualMode
bx r14

SetCasualMode:
push {r14}
ldr r0,=CasualModeFlagID
ldr r1,=SetCasualMode_return+1
mov r14,r1
ldr r1,=0x80798E4+1
mov r15,r1
SetCasualMode_return:
pop {r1}
bx r1

OffCasualMode:
push {r14}
ldr r0,=CasualModeFlagID
ldr r1,=OffCasualMode_return+1
mov r14,r1
ldr r1,=0x8079910+1
mov r15,r1
OffCasualMode_return:
pop {r1}
bx r1
.pool



CasualModeOption_display:
push {r14}
ldr r0,=CasualModeFlagID
ldr r1,=CasualModeOption_display_return+1
mov r14,r1
ldr r1,=0x80798F8+1
mov r15,r1
CasualModeOption_display_return:
pop {r1}
bx r1
.pool





