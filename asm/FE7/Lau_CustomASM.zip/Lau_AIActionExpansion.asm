
ExtraAIStealCheck:
mov r0,r3
add r0,0x40
ldrb r0,[r0,0x1]
mov r1,0x80
and r0,r1
cmp r0,0x0
bne AIStealDisabled
mov r0,r3
ldr r1,=ExtraAISteal_return+1
mov r14,r1
ldr r1,=0x80176DC+1
mov r15,r1
ExtraAISteal_return:
cmp r0,0x4
bgt AIStealDisabled
ldr r0,=0x80385E4+1
mov r15,r0

AIStealDisabled:
ldr r0,=0x80385FE+1
mov r15,r0
.pool

