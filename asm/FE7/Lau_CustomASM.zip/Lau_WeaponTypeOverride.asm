
WeaponOverrideP2:
ldrh r2,[r7,0x2]
cmp r0,0x1
beq RangeTypeOverride
cmp r0,0x2
bgt KeepWeaponType
cmp r2,0x1
bgt KeepWeaponType
b AlwaysTypeOverride

RangeTypeOverride:
cmp r2,0x2
blt KeepWeaponType

AlwaysTypeOverride:
ldrb r2,[r1,0x1]
strb r2,[r6]

KeepWeaponType:
ldrb r0,[r1,0x3]
lsl r0,r0,0x2
ldr r2,=OverrideDamageTypeTable
ldr r0,[r2,r0]
ldr r2,[r5,0x4C]
mov r15,r0
.pool

OverrideDamageTypeTable:
.dw AlwaysMagic+1
.dw AlwaysPhysical+1
.dw MeleePhysical+1
.dw MeleeMagic+1

AlwaysMagic:
mov r0,0x41
orr r2,r0
str r2,[r5,0x4C]
b Override_return

AlwaysPhysical:
mov r0,0x41
neg r0,r0
and r2,r0
str r2,[r5,0x4C]
b Override_return

MeleePhysical:
ldrh r2,[r7,0x2]
cmp r2,0x1
ble AlwaysPhysical
b AlwaysMagic

MeleeMagic:
ldrh r2,[r7,0x2]
cmp r2,0x2
bge AlwaysMagic
b AlwaysPhysical

Override_return:
ldr r0,=0x8028920+1
mov r15,r0
.pool







