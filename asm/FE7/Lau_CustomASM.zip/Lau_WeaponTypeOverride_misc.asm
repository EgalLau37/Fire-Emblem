
.org 0x80288CA
ldr r7,=0x203A3D8
.org 0x80288E6
b 0x80288EC
.pool
ldr r1,=WeaponOverrideTable
WeaponOverrideLoop:
ldrb r2,[r1]
cmp r2,0x0
beq 0x8028920
cmp r0,r2
beq WeaponTypeOverride
add r1,0x4
b WeaponOverrideLoop
WeaponTypeOverride:
ldrb r0,[r1,0x2]
cmp r0,0x2
bgt 0x8028920
cmp r0,0x0
bne SetDamageType
ldr r0,=AlwaysTypeOverride+1
mov r15,r0
SetDamageType:
ldr r2,=WeaponOverrideP2+1
mov r15,r2
.pool


