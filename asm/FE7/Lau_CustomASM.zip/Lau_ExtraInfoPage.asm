
CharacterPage_Biography:
push {r4-r7,r14}
add sp,#-0x8
ldr r0,=0x2028D58
ldr r1,=0x6001400
mov r2,0x80
mov r3,0x0
ldr r4,=ReturnGraphicClear2+1
mov r14,r4
ldr r4,=0x80053D4+1;3B0+1;
mov r15,r4
ReturnGraphicClear2:
ldr r1,=0x2028D78
mov r0,0xFF
strb r0,[r1]
ldr r0,=ReturnGraphicClear3+1
mov r14,r0
ldr r0,=0x8004CE8+1
mov r15,r0
ReturnGraphicClear3:
ldr r0,=ClearGraphicsTable
ldr r1,=ReturnWindowSetup+1	;clears RAM area for text graphics
mov r14,r1
ldr r1,=0x80054C4+1
;ldr r1,=0x807FA38+1
mov r15,r1

ReturnWindowSetup:
ldr r0,=0x2028D58
ldr r1,=0x6001000
str r1,[r0]
;mov r1,0x80
;strb r1,[r0,0x10]

ldr r0,=#0x83FCAC0	;sets up window
ldr r1,=#0x2020140
ldr r2,=#ReturnWindow+1
mov r14,r2
ldr r2,=#0x8013168+1
mov r15,r2

ReturnWindow:
ldr r0,=0x200373C	;draws window
mov r2,0x80
lsl r2,r2,0x5
ldr r1,=#0x2020140
ldr r4,=#ReturnWindowPart2+1
mov r14,r4
ldr r4,=0x80C57B4+1
mov r15,r4

ReturnWindowPart2:
ldr r0,=0x83FCE2C
ldr r1,=0x2020140
ldr r2,=#ReturnClearText+1
mov r14,r2
ldr r2,=0x8013168+1
mov r15,r2

;8016668 - draws icon+text for weapons	
;8005580 - registers text parameters for 8012C60?
;8005590 - sets name graphics to location
;r1 - location
;r0 - graphic?

ReturnClearText:
mov r7,0x0
ExtraPageInfoLoop:
ldr r0,=#ExtraInfoTextIDTable	;sets up text parameters
lsl r1,r7,0x4
add r0,r1
ldr r0,[r0,0x8]
ldr r1,=#ReturnTextParameters+1
mov r14,r1
ldr r1,=#0x80054E0+1
mov r15,r1

ReturnTextParameters:
ldr r0,=#ExtraInfoTextIDTable	;sets up text parameters
lsl r1,r7,0x4
add r0,r1
ldrb r1,[r0,0x2]
ldrh r2,[r0,0xC]
ldrh r3,[r0,0xE]
ldr r0,[r0,0x8]
strb r1,[r0,0x3]
strh r2,[r0]
strh r3,[r0,0x4]


ReturnTextIDSetup:
ldr r0,=#ExtraInfoTextIDTable	;sets up text
lsl r1,r7,0x4
add r0,r1
ldrh r0,[r0]
ldr r1,=#ReturnTextMisc+1
mov r14,r1
ldr r1,=#0x8012C61
mov r15,r1


ReturnTextMisc:
mov r0,0x0
mov r1,0x0
mov r2,0x0
ldr r5,=#ReturnUnknownSetup+1
mov r14,r5
ldr r5,=#0x8012F15
mov r15,r5

ReturnUnknownSetup:
mov r1,r0
ldr r0,=#ExtraInfoTextIDTable	;sets up text parameters
lsl r2,r7,0x4
add r0,r2
ldr r0,[r0,0x8]
ldr r2,=#ReturnTextDraw+1
mov r14,r2
ldr r2,=#0x8005719
mov r15,r2

ReturnTextDraw:
ldr r0,=#ExtraInfoTextIDTable	;draws text
lsl r2,r7,0x4
add r0,r2
ldr r1,[r0,0x4]
ldr r0,[r0,0x8]
ldr r2,=#ReturnLoopCheck+1
mov r14,r2
ldr r2,=#0x8005591
mov r15,r2

ReturnLoopCheck:
add r7,0x1
cmp r7,0x5
blt ExtraPageInfoLoop





ldr r7,=0x200310C
ldr r7,[r7,0xC]
ldr r7,[r7]
ldr r1,=0x8BDCE4C
sub r1,r7,r1
mov r6,0x0

CalculateUnitIDLoop:
sub r1,0x34
add r6,0x1
cmp r1,0x0
bge CalculateUnitIDLoop
ldr r5,=CharacterInformationTable
lsl r1,r6,0x5
add r5,r1
mov r7,r5
ldrh r0,[r7,0x4]
cmp r0,0x0
beq ReturnAddress_extension
ldrh r0,[r7]
cmp r0,0x8
bgt ReturnAddress_extension
lsl r0,r0,0x2
ldr r1,=FactionCheckRoutineTable
add r1,r0,r1
ldr r0,=0x200310C
ldr r0,[r0,0xC]
ldrb r0,[r0,0xB]
ldr r1,[r1]
mov r15,r1
b ReturnAddress_extension

FactionCheck_Player:
cmp r0,0x40
blt SkipFactionCheck
b ReturnAddress_extension

FactionCheck_Enemy:
cmp r0,0x80
blt ReturnAddress_extension
cmp r0,0xC0
bge ReturnAddress_extension
b SkipFactionCheck

FactionCheck_PlayerEnemy:
cmp r0,0x40
blt SkipFactionCheck
cmp r0,0xC0
bge ReturnAddress
cmp r0,0x80
bge SkipFactionCheck
b ReturnAddress

FactionCheck_NPC:
cmp r0,0x40
blt ReturnAddress
cmp r0,0x80
bge ReturnAddress
b SkipFactionCheck

FactionCheck_PlayerNPC:
cmp r0,0x80
bge ReturnAddress
b SkipFactionCheck

FactionCheck_EnemyNPC:
cmp r0,0x40
blt ReturnAddress
cmp r0,0xC0
bge ReturnAddress
b SkipFactionCheck


FactionCheckRoutineTable:
.dw ReturnAddress+1
.dw FactionCheck_Player+1
.dw FactionCheck_Enemy+1
.dw FactionCheck_PlayerEnemy+1
.dw FactionCheck_NPC+1
.dw FactionCheck_PlayerNPC+1
.dw FactionCheck_EnemyNPC+1
.dw FactionCheck_PlayerEnemyNPC+1
.dw ReturnAddress+1

ReturnAddress_extension:
b ReturnAddress

FactionCheck_PlayerEnemyNPC:
SkipFactionCheck:
ldrh r0,[r7,0x2]
cmp r0,0x0
beq SkipFlagCheck

ldr r1,=FlagCheckReturn+1
mov r14,r1
ldr r1,=0x80798F8+1
mov r15,r1
FlagCheckReturn:
cmp r0,0x0
beq ReturnAddress

SkipFlagCheck:
add r7,0x4
ldr r6,=CharacterTextLocations

mov r5,0x0
ExtraPageTextsLoop:	;sets up text parameters
ldr r0,[r6,0x4]
ldr r1,=#ReturnTextParameters2+1
mov r14,r1
ldr r1,=#0x80054E0+1
mov r15,r1

ReturnTextParameters2:	;sets up text parameters
ldr r0,[r6,0x4]
ldrb r1,[r7,0x6]
strb r1,[r0,0x3]
ldrh r1,[r6,0x8]
strh r1,[r0,0x4]
strh r1,[r0,0xC]

ldrh r2,[r6,0xA]
strh r2,[r0]
add r1,r1,r2
strh r1,[r0,0x8]

ReturnTextIDSetup2:	;sets up text
ldrh r0,[r7]
ldr r1,=#ReturnTextMisc2+1
mov r14,r1
ldr r1,=#0x8012C60+1	;writes to 202A5B4
mov r15,r1

ReturnTextMisc2:
push {r0}
mov r0,0x0
mov r1,0x0
mov r2,0x0
ldr r3,=#ReturnMultipleLineCheck+1
mov r14,r3
ldr r3,=#0x8012F14+1
mov r15,r3

ReturnMultipleLineCheck:
pop {r1}
push {r0}
mov r0,r1
ldr r1,=ReturnMultipleLineSetup+1
mov r14,r1
ldr r1,=0x8086960+1	;checks for multiple lines
mov r15,r1

ReturnMultipleLineSetup:
mov r4,r0
cmp r0,0x0
beq ReturnUnknownSetup2
push {r4}
mov r1,r4
ldr r4,[r6,0x4]
add r4,0x8
mov r0,0x2E
ldr r2,=ReturnSetSecondLine+1
mov r14,r2
ldr r2,=0x80056A8+1
mov r15,r2

ReturnSetSecondLine:
mov r1,0x0;mov r1,r0
ldr r0,[r6,0x4]
add r0,0x8
mov r2,0x0
pop {r3}
ldr r4,=ReturnDrawSecondLine+1
mov r14,r4
ldr r4,=0x8005B18+1
mov r15,r4


ReturnDrawSecondLine:
ldr r1,[r6]
ldr r0,[r6,0x4]
add r1,0x80
add r0,0x8
ldr r2,=#ReturnUnknownSetup2+1
mov r14,r2
ldr r2,=#0x8005590+1
mov r15,r2


ReturnUnknownSetup2:	;sets up text parameters
pop {r1}
ldr r0,[r6,0x4]
ldr r2,=#ReturnTextDraw2+1
mov r14,r2
ldr r2,=#0x8005718+1
mov r15,r2

ReturnTextDraw2:	;draws text
ldr r1,[r6]
ldr r0,[r6,0x4]
ldr r2,=#ReturnLoopCheck2+1
mov r14,r2
ldr r2,=#0x8005590+1
mov r15,r2

ReturnLoopCheck2:
add r7,0x4
add r6,0xC
add r5,0x1
cmp r5,0x6
blt ExtraPageTextsLoop


ReturnAddress:
add sp,#0x8
pop {r4-r7}
pop {r0}
bx r0

.pool

.align 4
ExtraInfoTextIDTable:
.dh TextID_Likes
.db 0x2
.db 0x0
.dw 0x200327E
.dw 0x200319C
.dh 0x10
.dh 0x4

.dh TextID_Dislikes
.db 0x2
.db 0x0
.dw 0x200337E
.dw 0x20031A4
.dh 0x14
.dh 0x6

.dh TextID_Age
.db 0x3
.db 0x0
.dw 0x200347E
.dw 0x20031AC
.dh 0x1A
.dh 0x4

.dh TextID_Height
.db 0x3
.db 0x0
.dw 0x200348C
.dw 0x20031B4
.dh 0x1E
.dh 0x4

.dh TextID_Affiliation
.db 0x4
.db 0x0
.dw 0x2003500
.dw 0x20031BC
.dh 0x22
.dh 0x6


CharacterTextLocations:
.dw 0x2003288	;likes
.dw 0x20031C4
.dh 0xC
.dh 0x28
.dw 0x2003388	;dislikes
.dw 0x20031D4
.dh 0xC
.dh 0x40
.dw 0x2003484	;age
.dw 0x20031E4
.dh 0x4
.dh 0x58
.dw 0x2003494	;height
.dw 0x20031EC
.dh 0x8
.dh 0x5C
.dw 0x200350C	;affiliation
.dw 0x20031F4
.dh 0x8
.dh 0x64
.dw 0x200357E	;quote
.dw 0x20031FC
.dh 0x10
.dh 0x6C


