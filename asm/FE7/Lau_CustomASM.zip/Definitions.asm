
TextID_Likes		equ 0xB00
TextID_Dislikes		equ 0xB01
TextID_Age			equ 0xB02
TextID_Height		equ 0xB03
TextID_Affiliation	equ 0xB04

CasualModeFlagID	equ 0xA0

